<?php
	require_once "lib/captcha_class.php";
	Captcha::generate();
?>