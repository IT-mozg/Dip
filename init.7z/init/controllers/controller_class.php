<?php 

abstract class Controller extends AbstractController {

	protected $title;
	protected $meta_desc;
	protected $meta_key;
	protected $mail = null;
	protected $url_active;

	public function __construct() {
		parent::__construct(new View(Config::DIR_TMPL), new Message(Config::FILE_MESSAGES));
		$this->mail = new Mail();
		$this->url_active = URL::deleteGET(URL::current(), "page");
	}

	public function action404(){
		header("HTTP/1.1 404 Not Found");
		header("Status: 404 Not Found");
		$this->title = "Page not found - 404";
		$this->meta_desc = "The requested page does not exist";
		$this->meta_key = "page not found, page does not exist, page 404, 404";

		$pm = new PageMessage();
		$pm->header = "Page not found";
		$pm->text = "Unfortunately, the requested page does not exist. Check the correctness of the address.";
		$this->render($pm);
	}

	protected function accessDenied(){
		$this->title = "Access denied!";
		$this->meta_desc = "Access to this page is denied.";
		$this->meta_key = "access denied, access denied page, access denied page 403";

		$pm = new PageMessage();
		$pm->header = "Access denied!";
		$pm->text = "You do not have rights to this page.";
		$this->render($pm);
	}

	final protected function render($center, $slider = ""){
		$params = array();
		$params["header"] = $this->getHeader();
		$params["topmenu"] = $this->getTopMenu();
		$params["user_panel"] = $this->getUserPanel();
		$params["slider"] = $slider;
		$params["center"] = $center;
		$params["footermenus"] = $this->getFooterMenus();
		$this->view->render("main", $params);
	}

	protected function getHeader(){
		$header = new Header();
		$header->title = $this->title;
		$header->meta("Content-Type", "text/html; charset=utf-8", true);
		$header->meta("description", $this->meta_desc, false);
		$header->meta("keywords", $this->meta_key, false);
		$header->favicon = "/favicon.ico";
		$header->css = array("/css/font.css", "/css/bootstrap.min.css", "/css/bootstrap_skin.css", "/slick/slick.css", "/slick/slick-theme.css",
			"/css/main.css", "/css/media.css");
		$header->js = array("/js/jquery-3.2.1.min.js", "/js/validator.js");
		return $header;
	}

	protected function getTopMenu(){
		$items = MenuDB::getTopMenu();
		$top = new TopMenu();
		$top->uri = $this->url_active;
		$top->items = $items;
		return $top;
	}

	protected function getUserPanel(){
		$user_panel = new UserPanel();
		$user_panel->user = $this->auth_user;
		$user_panel->link_auth = URL::get("auth");
		$user_panel->link_register = URL::get("register");
		$user_panel->items = MenuDB::getProfileMenu();
		return $user_panel;
	}

	protected function getFooterMenus(){
		$fmenus = new FooterMenus();
		$items = MenuDB::getTopMenu();
		$fmenus->addMenu("MENU", $items);
		
		return $fmenus;
	}

	protected function getSlider(){
		$slider = new Slider();
		$items = SlideDB::getAllSlides();
		$slider->items = $items;
		return $slider;
	}

	final protected function getOffset($count_on_page){
		return $count_on_page * ($this->getPage() - 1);
	}

	final protected function getPage() {
		$page = ($this->request->page) ? $this->request->page : 1;
		if($page < 1) $this->notFound();
		return $page;
	}

	final protected function getPagination($count_elements, $count_on_page, $url = false){
		$count_pages = ceil($count_elements / $count_on_page);
		$active = $this->getPage();
		if (($active > $count_pages) && ($active > 1)) $this->notFound();
		$pagination = new Pagination();
		if(!$url) $url = URL::deletePage(URL::current());
		$pagination->url = $url;
		$pagination->url_page = URL::addTemplatePage($url);
		$pagination->count_elements = $count_elements;
		$pagination->count_on_page = $count_on_page;
		$pagination->count_show_pages = Config::COUNT_SHOW_PAGES;
		$pagination->active = $active;
		return $pagination;
	}

	protected function authUser() {
		$login = "";
		$password = "";
		$redirect = false;
		if ($this->request->auth) {
			$login = $this->request->login;
			$password = $this->request->password;
			$redirect = true;
		}
		$user = $this->fp->auth("auth", "UserDB", "authUser", $login, $password);
		if ($user instanceof UserDB) {
			
			if ($redirect) $this->redirect(URL::get("index"));
			return $user;
		}
		return null;
	}
}

 ?>