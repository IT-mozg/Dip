<?php 

class MainController extends Controller{

	public function actionIndex(){
		$this->title = "Init company - articles - HOME";
		$this->meta_desc = "Init - young Ukrainian company which is developing computer games and software designed";
		$this->meta_key = "init, young Ukrainian company, init Ukrainian company, init young Ukrainian company";
		$articles = ArticleDB::getAllShow(Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE), true);
		$pagination = $this->getPagination(ArticleDB::getCount(), Config::COUNT_ARTICLES_ON_PAGE, "/");
		$blog = new Blog();
		$blog->articles = $articles;
		$blog->pagination = $pagination;
		$this->render($this->renderData(array("blog" => $blog), "index"), $this->getSlider());
	}

	public function actionArticle(){
		$article_db = new ArticleDB();
		$article_db->load($this->request->id);
		if(!$article_db->isSaved()) $this->notFound();
		$this->title = $article_db->title;
		$this->meta_desc = $article_db->meta_desc;
		$this->meta_key = $article_db->meta_key;

		$prev_article_db = new ArticleDB();
		$prev_article_db->loadPrevArticle($article_db);
		$next_article_db = new ArticleDB();
		$next_article_db->loadNextArticle($article_db);

		$article = new Article();
		$article->article = $article_db;

		if ($prev_article_db->isSaved()) $article->prev_article = $prev_article_db;
		if ($next_article_db->isSaved()) $article->next_article = $next_article_db;

		$article->sidebar = $this->getSidebar(array(array(new CategoryDB, "Category", 1)));

		$this->render($article, $this->getSlider());
	}

	public function actionNews(){
		$this->title = "Init company - News";
		$this->meta_desc = "Our news";
		$this->meta_key = "init news, news";
		$news = ArticleDB::getAllbyType(NEWSTYPE, false, Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE));
		$pagination = $this->getPagination(ArticleDB::getCountArticles("type", NEWSTYPE), Config::COUNT_ARTICLES_ON_PAGE, "news");
		$newsblog = new NewsBlog();
		$newsblog->news = $news;
		$newsblog->pagination = $pagination;
		$sidebar = $this->getSidebar(array(array(new CategoryDB, "Category", 1)));

		return $this->render($this->renderData(array("content" => $newsblog, "sidebar" => $sidebar, "topitem" => ""), "newslayout"), $this->getSlider());
	}

	public function actionCategory(){
		$category_db = new CategoryDB();
		$category_db->load($this->request->id);
		$this->title = "Init company - ".$category_db->title;
		$this->meta_desc = "Category - ".$category_db->title;
		$this->meta_key = $category_db->title;
		$articles = ArticleDB::getAllOnCatID($this->request->id, false, Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE));
		$pagination = $this->getPagination(ArticleDB::getCountArticles("cat_id", $this->request->id), Config::COUNT_ARTICLES_ON_PAGE, "category?id=".$this->request->id);
		$sidebar = $this->getSidebar(array(array(new CategoryDB, "Category", 1)));
		$newsblog = new NewsBlog();
		$newsblog->news = $articles;
		$newsblog->pagination = $pagination;
		return $this->render($this->renderData(array("content" => $newsblog, "sidebar" => $sidebar, "topitem" => ""), "newslayout"), $this->getSlider());
	}

	public function actionRegister(){
		$message_name = "register";

		if ($this->request->register) {
			$user_old_1 = new UserDB();
			$user_old_1->loadOnEmail($this->request->email);
			$user_old_2 = new UserDB();
			$user_old_2->loadOnLogin($this->request->login);
			$captcha = $this->request->captcha;
			$checks = array(array(Captcha::check($captcha), true, "ERROR_CAPTCHA_CONTENT"));
			$checks[] = array($this->request->password, $this->request->password_conf, "ERROR_PASSWORD_CONF");
			$checks[] = array($user_old_1->isSaved(), false, "ERROR_EMAIL_ALREADY_EXISTS");
			$checks[] = array($user_old_2->isSaved(), false, "ERROR_LOGIN_ALREADY_EXISTS");
			$user = new UserDB();
			$fields = array("fullName", "login", "email", array("setPassword()", $this->request->password));
			$user = $this->fp->process($message_name, $user, $fields, $checks);
			//echo 23234234234;
			if ($user instanceof UserDB) {
				$this->mail->send($user->email, array("user" => $user, "link" => URL::get("activate", "", array("login" => $user->login, "key" => $user->activate), false, Config::ADDRESS)), "register");
				$this->redirect(URL::get("sregister"));
			}
		}

		$this->title = "Registration on the site ".Config::SITENAME;
		$this->meta_desc = "Registration on the site ".Config::SITENAME.".";
		$this->meta_key = "registration site ".mb_strtolower(Config::SITENAME).", register site ".mb_strtolower(Config::SITENAME);

		$form = new Form();
		$form->header = "Join us";
		$form->name = "register";
		$form->action = URL::current();
		$form->message = $this->fp->getSessionMessage($message_name);
		$form->text("fullName", "Full name:", $this->request->fullName);
		$form->text("login", "Login:", $this->request->login);
		$form->text("email", "E-mail:", $this->request->email);
		$form->password("password", "Password:");
		$form->password("password_conf", "Confirm the password:");
		$form->captcha("captcha", "Enter the code from the image:");
		$form->submit("Join");
		
		$form->addJSV("name", $this->jsv->name());
		$form->addJSV("login", $this->jsv->login());
		$form->addJSV("email", $this->jsv->email());
		$form->addJSV("password", $this->jsv->password("password_conf"));
		$form->addJSV("captcha", $this->jsv->captcha());
		
		return $this->render($this->renderData(array("content" => $form, "sidebar" => "", "topitem" => ""), "newslayout"), "");
	}

	public function actionSRegister() {
		$this->title = "Registration on the site ".Config::SITENAME;
		$this->meta_desc = "Registration on the site ".Config::SITENAME.".";
		$this->meta_key = "registration site ".mb_strtolower(Config::SITENAME).", sign up site ".mb_strtolower(Config::SITENAME);
		
		$pm = new PageMessage();
		$pm->header = "Registration";
		$pm->text = "The account has been created. A letter with the activation instruction was sent to your e-mail address. If the letter does not reach, then contact the administration.";
		$this->render($pm);
	}

	public function actionActivate() {
		$user_db = new UserDB();
		$user_db->loadOnLogin($this->request->login);
		if ($user_db->isSaved() && $user_db->activate == "") {
			$this->title = "Your account is already activated";
			$this->meta_desc = "You can log in to your account using your login and password.";
			$this->meta_key = "activation, successful activation";
		}
		elseif ($user_db->activate != $this->request->key) {
			$this->title = "Activation error";
			$this->meta_desc = "Invalid activation code! If the error persists, contact the administration.";
			$this->meta_key = "activation, activation error, activation error registration";
		}
		else {
			$user_db->activate = "";
			try {
				$user_db->save();
			} catch (Exception $e) {
				print_r($e);
			}
			$this->title = "Your account has been successfully activated";
			$this->meta_desc = "Now you can log in to your account using your login and password.";
			$this->meta_key = "activation, successful activation";
		}
		
		$pm = new PageMessage();
		$pm->header = $this->title;
		$pm->text = $this->meta_desc;
		$this->render($pm);
	}

	public function actionAuth(){
		if($this->auth_user) return $this->action404();
		$message_name = "auth";
		$this->title = "Authorization on the site ".Config::SITENAME;
		$this->meta_desc = "Authorization on the site ".Config::SITENAME.".";
		$this->meta_key = "authorization site ".mb_strtolower(Config::SITENAME).", sign in site ".mb_strtolower(Config::SITENAME);

		$form = new Form();
		$form->header = "Sign in";
		$form->name = "auth";
		$form->action = URL::current();
		$form->message = $this->fp->getSessionMessage($message_name);
		$form->text("login", "Login:", $this->request->login);
		$form->password("password", "Password:");
		$form->submit("Sign in");

		$form->addJSV("login", $this->jsv->login());
		$form->addJSV("password", $this->jsv->password());
		
		return $this->render($this->renderData(array("content" => $form, "sidebar" => "", "topitem" => ""), "newslayout"), "");
	}

	public function actionLogout() {
		UserDB::logout();
		$this->redirect($_SERVER["HTTP_REFERER"]);
	}

	public function actionForum($args = array()){
		if(count($args) > 2) throw new Exception();
		$sidebar = new SidebarMenus();
		$items = ForumDB::getAllOffset(10);
		$sidebar->addmenu("Last discussions", $items, 0);
		if(isset($args[0])){
			$topitem = $this->getTopForumPanel();
			
			$forum_db = new ForumDB();
			$forum_db->load($args[0]);
			$this->title = "Forum - ".$forum_db->title;
			$this->meta_desc = $forum_db->meta_desc;
			$this->meta_key = $forum_db->meta_key;
			$pagination_s = $this->getPagination(SubForumDB::getCountByForumID($forum_db->id), Config::COUNT_ARTICLES_ON_PAGE, "/forum/".$forum_db->id);
			$subforums = SubForumDB::getAllByForumID($forum_db->id,Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE));
			if(count($subforums) === 0) throw new Exception();
			$modulesub = new SubForums();
			$modulesub->subforums = $subforums;
			$modulesub->header = $forum_db->title;
			$modulesub->pagination = $pagination_s;
			return $this->render($this->renderData(array("content" => $modulesub, "sidebar" => $sidebar, "topitem" => $topitem), "newslayout"));
		}
		$this->title = "Init company - Forum";
		$this->meta_desc = "Forum";
		$this->meta_key = "forum, disscussing";

		$forums = ForumDB::getAllOffset(Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE));
		$pagination_f = $this->getPagination(ForumDB::getCount(), Config::COUNT_ARTICLES_ON_PAGE, "/forum");

		$forum = new Forums();
		$forum->forums = $forums;
		$forum->pagination = $pagination_f;
		return $this->render($this->renderData(array("content" => $forum, "sidebar" => $sidebar, "topitem" => ""), "newslayout"), $this->getSlider());

	}

	public function actionSubforum(){
		$subforum_db = new SubForumDB();
		$subforum_db->load($this->request->id);
		$this->title = "Init company - ".$subforum_db->title;
		$this->meta_desc = $subforum_db->meta_desc;
		$this->meta_key = $subforum_db->meta_key;

		$discus = new Discussion();
		$discus->auth_user = $this->auth_user;
		$discus->subforum = $subforum_db;
		$discus->comments = CommentDB::getAllOnForumID($subforum_db->id);
		$addtopic = $this->getTopForumPanel();

		return $this->render($this->renderData(array("content" => $discus, "topitem" => $addtopic), "forumitemlayout"));
	}

	public function actionStore(){
		$this->title = "INIT company - Store";
		$this->meta_desc = "Store";
		$this->meta_key = "Store";
		$products = ProductDB::getAllShow(Config::COUNT_ARTICLES_ON_PAGE, $this->getOffset(Config::COUNT_ARTICLES_ON_PAGE), true);
		$pagination = $this->getPagination(ArticleDB::getCount(), Config::COUNT_ARTICLES_ON_PAGE, "/store");
		$store = new Store();
		$store->products = $products;
		$store->pagination = $pagination;
		$this->render($store, $this->getSlider());
	}

	public function actionProduct(){
		if($this->request->add_cart){
			$this->add_cart();
			$this->redirect($_SERVER["HTTP_REFERER"]);
		}
		$product_db = new ProductDB();
		$product_db->load($this->request->id);
		$this->title = $product_db->title;
		$this->meta_desc = $product_db->meta_desc;
		$this->meta_key = $product_db->meta_key;

		$product = new Product();
		$product->product = $product_db;

		$this->render($product, $this->getSlider());
	}

	

	private function add_cart(){
		$order = new OrderDB();
		$order->product_id = $this->request->add_cart;
		$order->user_id = $this->auth_user->id;
		$orderChek = OrderDB::chekOrder($order->product_id, $order->user_id);
		if($orderChek) return;
		$order->save();
	}

	private function getTopForumPanel(){
		$message_name = "addtopic";
		if($this->request->addtopic){
			$new_discus = new SubForumDB();
			$checks = array(array(ObjectDB::isEmpty($this->request->title), true, "ERROR_TITLE_EMPTY"));
			$checks[] = array(ObjectDB::isEmpty($this->request->text), true, "ERROR_TEXT_EMPTY");
			$checks[] = array(ObjectDB::isEmpty($this->request->forum_id), true, "ERROR_FORUM_EMPTY");
			$fields = array("title", "text", "forum_id", array("user", $this->auth_user->id), array("meta_desc", $this->request->title), array("meta_key", ObjectDB::setMeta_key($this->request->title)));
			$discus = $this->fp->process($message_name, $new_discus, $fields, $checks);
			if ($new_discus instanceof SubForumDB) $this->redirect(URL::current());
		}
		$form = new Form();
		$form->name = "addtopic";
		$form->header = "";
		$form->message = $this->fp->getSessionMessage($message_name);
		$form->action = URL::current();
		$form->text("title", "", "", "Enter topic", "topic_name");
		$form->textarea("text", "", "", "Enter text", "topic_text");
		$form->select("forum_id", "", "select_theme", ForumDB::getAll());
		$form->submit("Add disscussing", false, "add_discus");


		$addTopik = new AddTopik();
		$addTopik->auth_user = $this->auth_user;
		$addTopik->form = $form;

		return $addTopik;
	}
	
	private function getSidebar($arr){
		$sidebar = new SidebarMenus();
		foreach($arr as $i){
			$items = $i[0]->getAll();
			$sidebar->addMenu($i[1], $items, $i[2]);
		}		
		return $sidebar;
	}
}

 ?>