<?php 

class UserController extends Controller{

	public function actionProfile(){
		if(!$this->access()) return $this->accessDenided();

		$this->title = "Profile - ".$this->auth_user->login;
		$this->meta_desc = "User profile - ".$this->auth_user->login;
		$this->meta_key = "user, profile, ".$this->auth_user->login;

		$products = OrderDB::getByUserID($this->auth_user->id);
		$prof_prod = new ProfileProduct();
		$prof_prod->products = $products;
		$profnav = $this->getProfileSidebar();
		$header = "Your products";
		$this->render($this->renderData(array("header" => $header, "profileproduct" => $prof_prod, "profilenav" => $profnav, "auth_user" => $this->auth_user), "profilelayout"));
	}

	public function actionCart(){
		if(!$this->access()) return $this->accessDenided();
		if($this->request->delete_cart){
			$this->delete_cart();
		}
		$this->title = "Cart - ".$this->auth_user->login;
		$this->meta_desc = "User Cart - ".$this->auth_user->login;
		$this->meta_key = "user, cart, ".$this->auth_user->login;

		$products = OrderDB::getByUserID($this->auth_user->id);
		$prof_prod = new Cart();
		$prof_prod->products = $products;
		$prof_prod->action = URL::current();
		$prof_prod->name = "pay";
		$profnav = $this->getProfileSidebar();
		$header = "Orders";
		$this->render($this->renderData(array("header" => $header, "profileproduct" => $prof_prod, "profilenav" => $profnav, "auth_user" => $this->auth_user), "profilelayout"));
	}

	public function actionSetings(){
		if(!$this->access()) return $this->accessDenided();
		$message_avatar_name = "avatar";
		$message_name_name = "name";
		$message_password_name = "password";

		if ($this->request->change_avatar) {
			$img = $this->fp->uploadIMG($message_avatar_name, $_FILES["avatar"], Config::MAX_SIZE_AVATAR, Config::DIR_AVATAR);
			if ($img) {
				$tmp = $this->auth_user->getAvatar();
				$obj = $this->fp->process($message_avatar_name, $this->auth_user, array(array("avatar", $img)), array(), "SUCCESS_AVATAR_CHANGE");
				if ($obj instanceof UserDB) {
					if ($tmp) File::delete(Config::DIR_AVATAR.$tmp);
					$this->redirect(URL::current());
				}
			}
		}
		elseif ($this->request->change_name) {
			$checks = array(array($this->auth_user->checkPassword($this->request->password_current_name), true, "ERROR_PASSWORD_CURRENT"));
			$user_temp = $this->fp->process($message_name_name, $this->auth_user, array("fullName"), $checks, "SUCCESS_NAME_CHANGE");
			if ($user_temp instanceof UserDB) $this->redirect(URL::current());
		}
		elseif ($this->request->change_password) {
			$checks = array(array($this->auth_user->checkPassword($this->request->password_current), true, "ERROR_PASSWORD_CURRENT"));
			$checks[] = array($this->request->password, $this->request->password_conf, "ERROR_PASSWORD_CONF");
			$user_temp = $this->fp->process($message_password_name, $this->auth_user, array(array("setPassword()", $this->request->password)), $checks, "SUCCESS_PASSWORD_CHANGE");
			if ($user_temp instanceof UserDB) {
				$this->auth_user->login();
				$this->redirect(URL::current());
			}
		}

		$this->title = "Редактирование профиля";
		$this->meta_desc = "Редактирование профиля пользователя.";
		$this->meta_key = "редактирование профиля, редактирование профиля пользователя, редактирование профиля пользователя сайт";

		$header = "Setings";

		$form_avatar = new Form();
		$form_avatar->name = "change_avatar";
		$form_avatar->header = "Change avatar";
		$form_avatar->action = URL::current();
		$form_avatar->enctype = "multipart/form-data";
		$form_avatar->message = $this->fp->getSessionMessage($message_avatar_name);
		$form_avatar->file("avatar", "Avatar:", "Select avatar", "form_btn");
		$form_avatar->submit("Save");
		
		$form_avatar->addJSV("avatar", $this->jsv->avatar());

		$form_name = new Form();
		$form_name->name = "change_name";
		$form_name->header = "Change name - <br>".$this->auth_user->fullName;
		$form_name->action = URL::current();
		$form_name->message = $this->fp->getSessionMessage($message_name_name);
		$form_name->text("fullName", "Your name:", $this->auth_user->name);
		$form_name->password("password_current_name", "Current password:");
		$form_name->submit("Save");
		
		$form_name->addJSV("name", $this->jsv->name());
		$form_name->addJSV("password_current_name", $this->jsv->password(false, false, "ERROR_PASSWORD_CURRENT_EMPTY"));

		$form_password = new Form();
		$form_password->name = "change_password";
		$form_password->header = "Change password";
		$form_password->action = URL::current();
		$form_password->message = $this->fp->getSessionMessage($message_password_name);
		$form_password->password("password", "New password:");
		$form_password->password("password_conf", "Repeat password:");
		$form_password->password("password_current", "Current pasword:");
		$form_password->submit("Save");
		
		
		$form_password->addJSV("password", $this->jsv->password("password_conf"));
		$form_password->addJSV("password_current", $this->jsv->password(false, false, "ERROR_PASSWORD_CURRENT_EMPTY"));


		$this->render($this->renderData(array("form_avatar" => $form_avatar, "form_name" => $form_name, "form_password" => $form_password, "form_email" => "", "profilenav" => $this->getProfileSidebar()), "setings", array("auth_user" => $this->auth_user, "header" => $header)));

	}

	private function delete_cart(){
		$obj = new OrderDB();
		$obj->load($this->request->delete_cart);
		if ($obj->accessDelete($this->auth_user)) {
			try {
				if (!$obj->delete()) throw new Exception();
				return true;
			} catch (Exception $e) {
				return false;
			}
		}
		return false;
	}

	private function getProfileSidebar(){
		$profnav = new ProfileNav();
		$profnav->uri = Url::current();
		$profnav->items = MenuDB::getProfileMenu();
		return $profnav;
	}

	protected function access() {
		if ($this->auth_user) return true;
		return false;
	}

}

 ?>