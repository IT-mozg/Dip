<?php

class Route {
	
	public static function start() {
		$ca_names = URL::getControllerAndAction();
		$controller_name = $ca_names[0]."Controller";
		$action_name = "action".$ca_names[1];
		if(isset($ca_names[2])) $arguments = $ca_names[2];
		try {
			if (class_exists($controller_name)) $controller = new $controller_name();
			if (method_exists($controller, $action_name)) {
				if(count($arguments) > 0){
					$r = new \ReflectionMethod($controller_name, $action_name);
					$ca = $r->getNumberOfParameters();
					if($ca > 0)
						$controller->$action_name($arguments);
					else 
						throw new Exception();
				}
				else $controller->$action_name();
			}
			else{
				throw new Exception();
			}

		} catch (Exception $e) {
			if ($e->getMessage() != "ACCESS_DENIED") $controller->action404();
		}
	}
	
}

?>