<?php 
	require_once "start.php";
	Route::start();
	
 ?>