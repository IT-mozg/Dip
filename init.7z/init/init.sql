-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июн 02 2017 г., 14:56
-- Версия сервера: 5.5.48
-- Версия PHP: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `init`
--

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_articles`
--

CREATE TABLE `dipinit_articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `intro` text NOT NULL,
  `text` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  `cat_id` int(10) UNSIGNED NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `date` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_articles`
--

INSERT INTO `dipinit_articles` (`id`, `title`, `intro`, `text`, `img`, `type`, `cat_id`, `meta_desc`, `meta_key`, `date`) VALUES
(1, 'Title 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 0, 1, 'title 1', 'title', 1494506065),
(2, 'New 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 1, 2, 'New 1', 'new', 1494506081),
(3, 'Title 3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 0, 2, 'title 3', 'title', 1494506109),
(4, 'Title 23', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'fc4.jpg', 0, 2, 'title 23', 'title', 1494506126),
(5, 'Title 23', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'fc4.jpg', 0, 2, 'title 23', 'title', 1494506140),
(6, 'New 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 1, 2, 'New 1', 'new', 1494506155),
(7, 'Title 3', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 0, 2, 'title 3', 'title', 1494506166),
(8, 'Title 1', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'post.jpg', 0, 1, 'title 1', 'title', 1494506178),
(9, 'fvdfv', 'zdfvzdfvdfvdfv', 'dfvdfvdfvdfvdfv', 'post.jpg', 1, 1, '', '', 1494506193),
(10, 'asdfasd', 'fasdfaasd', 'asdfasdf', '', 0, 1, 'sdfs', 'sdf', 1496250157);

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_categories`
--

CREATE TABLE `dipinit_categories` (
  `id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_categories`
--

INSERT INTO `dipinit_categories` (`id`, `title`) VALUES
(1, 'Category 1'),
(2, 'Category 2');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_comments`
--

CREATE TABLE `dipinit_comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `forum_id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `text` text NOT NULL,
  `date` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_comments`
--

INSERT INTO `dipinit_comments` (`id`, `user_id`, `forum_id`, `parent_id`, `text`, `date`) VALUES
(1, 3, 1, NULL, 'I know how i can help you', 1493984765),
(2, 4, 1, 1, 'No you don\'t know', 1493984765),
(3, 7, 2, NULL, 'ok', 1493984811);

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_forums`
--

CREATE TABLE `dipinit_forums` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `date` int(10) UNSIGNED NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `meta_key` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_forums`
--

INSERT INTO `dipinit_forums` (`id`, `title`, `date`, `meta_desc`, `meta_key`) VALUES
(1, 'About game 1', 1494779132, 'About game 1', 'about game, game 1, about game 1'),
(2, 'About game 2', 1494779145, 'About game 2', 'about game, game 1, about game 1'),
(3, 'Discussing 1', 1494779158, 'Discussing 1', 'disscussing'),
(4, 'About program 1', 1494779170, 'About program 1', 'about program, program 1, about program 1');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_genres`
--

CREATE TABLE `dipinit_genres` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_genres`
--

INSERT INTO `dipinit_genres` (`id`, `title`) VALUES
(1, 'Action'),
(2, 'MMO'),
(3, 'RPG'),
(4, 'Adventure'),
(5, 'Arcade'),
(6, 'Strategy'),
(7, 'Simulation'),
(8, 'Sports');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_menu`
--

CREATE TABLE `dipinit_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `external` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_menu`
--

INSERT INTO `dipinit_menu` (`id`, `type`, `title`, `link`, `parent_id`, `external`) VALUES
(1, 1, 'HOME', '/', NULL, 0),
(2, 1, 'NEWS', '/news/', NULL, 0),
(3, 1, 'STORE', '/store/', NULL, 0),
(4, 1, 'FORUM', '/forum/', NULL, 0),
(5, 2, 'Title 1', '/article?id=1/', NULL, 1),
(6, 2, 'Title 2', '/article?id=2/', NULL, 1),
(7, 3, 'Profile', '/user/profile', NULL, 0),
(8, 3, 'Shopping cart', '/user/cart', NULL, 0),
(9, 3, 'Setings', '/user/setings', NULL, 0),
(10, 3, 'Admin panel', '/admin/', NULL, 1),
(11, 3, 'Log out', '/logout/', NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_order`
--

CREATE TABLE `dipinit_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `date` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_order`
--

INSERT INTO `dipinit_order` (`id`, `product_id`, `user_id`, `date`) VALUES
(1, 1, 7, 1496246289),
(2, 2, 7, 1496246321);

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_platforms`
--

CREATE TABLE `dipinit_platforms` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_platforms`
--

INSERT INTO `dipinit_platforms` (`id`, `title`) VALUES
(1, 'PC'),
(2, 'PS4'),
(3, 'MAC OS'),
(4, 'Linux'),
(5, 'XBox one');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_products`
--

CREATE TABLE `dipinit_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `intro` text NOT NULL,
  `text` text NOT NULL,
  `intro_img` varchar(255) NOT NULL,
  `text_img` varchar(255) NOT NULL,
  `src` varchar(255) NOT NULL,
  `type` int(10) UNSIGNED NOT NULL,
  `genre_ids` varchar(255) NOT NULL,
  `platform_ids` varchar(255) NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `date` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_products`
--

INSERT INTO `dipinit_products` (`id`, `title`, `intro`, `text`, `intro_img`, `text_img`, `src`, `type`, `genre_ids`, `platform_ids`, `price`, `meta_desc`, `meta_key`, `date`) VALUES
(1, 'Game 1', 'intro', 'intro', 'intro_img.jpg', 'fc4.jpg', 'game.zip', 1, '1,2,3', '1,2,3', 15, 'Game 1', 'game1', 1495026377),
(2, 'Game 2', 'intro', 'intro', 'intro_img.jpg', 'fc4.jpg', 'game.zip', 1, '1,2,3', '1,2,3', 15, 'Game 1', 'game1', 1495026385);

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_slider`
--

CREATE TABLE `dipinit_slider` (
  `id` int(10) UNSIGNED NOT NULL,
  `img` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_slider`
--

INSERT INTO `dipinit_slider` (`id`, `img`, `title`, `description`) VALUES
(1, 'sl1.jpg', 'Cryzis', ''),
(2, 'sl2.jpg', 'Call of duty', ''),
(3, 'sl3.jpg', 'For Honor', ''),
(4, 'sl4.jpg', 'Top Rider', '');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_subforums`
--

CREATE TABLE `dipinit_subforums` (
  `id` int(10) UNSIGNED NOT NULL,
  `forum_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `user` int(10) UNSIGNED NOT NULL,
  `date` int(10) UNSIGNED NOT NULL,
  `meta_desc` varchar(255) NOT NULL,
  `meta_key` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_subforums`
--

INSERT INTO `dipinit_subforums` (`id`, `forum_id`, `title`, `text`, `user`, `date`, `meta_desc`, `meta_key`) VALUES
(1, 1, 'Pls help mee!!!!', 'I need help in game', 1, 1493984653, 'Pls help me', 'pls, help, me'),
(2, 2, 'Need help in passing game far cry', 'Need help in passing game far cry\r\npls help i do not know how to pass the level', 2, 1493984653, 'Need help in passing game far cry', 'need, help, in, passing, game, far, cry'),
(3, 2, 'Heeeeeeeeeeeelp', 'Neeeeeeeeeeeeeeeeeeeeeeeeed Heeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeelpppppppppp\r\nPLEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEAAAAAAAAAAAAAAAAAAAAAAS', 1, 1494788147, 'Heeeeeeeeeeeelp', 'heeeeeeeeeeeelp'),
(4, 2, 'dfg', 'dfg', 7, 1495029367, 'dfg', 'dfg'),
(5, 2, 'lol', 'lol', 7, 1495031044, 'lol', 'lol');

-- --------------------------------------------------------

--
-- Структура таблицы `dipinit_users`
--

CREATE TABLE `dipinit_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(32) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `perm` int(10) UNSIGNED NOT NULL,
  `date_reg` int(10) UNSIGNED NOT NULL,
  `activate` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `dipinit_users`
--

INSERT INTO `dipinit_users` (`id`, `fullName`, `login`, `email`, `password`, `avatar`, `perm`, `date_reg`, `activate`) VALUES
(1, 'Tkachuk Vladislav Oleksandrovish', 'Houston', 'vlad-tkachuk-98@mail.ru', '0d6905fa27d2441f3992a4c6d332cd95', NULL, 1, 1493985155, ''),
(2, 'Barilo Vladislav Oleksandrovich', 'VladBar', 'vladbar@mail.ru', '0d6905fa27d2441f3992a4c6d332cd95', NULL, 0, 1493985267, ''),
(3, 'Lavrenuk Vitaliy', 'lavrik', 'lavrik@mail.ru', '592ca9724b7069e03beae208a7ad28c4', NULL, 0, 1493985512, ''),
(4, 'Soloniy Max', 'soloniy', 'solon@mail.ru', 'bb80770b4686daec75492321ae0c7bd3', NULL, 1, 1493985512, ''),
(5, 'Dfgadfhsfghsf', 'qweqweq', 'eqwe@asdasd.asd', '26c94912da8f5cedc798a36663e5d3c4', NULL, 0, 1494246780, '5910657c61922'),
(6, 'Андрей Раду', 'radyAndrew', 'redutoday@mail.com', '26c94912da8f5cedc798a36663e5d3c4', NULL, 0, 1494247949, '59106a0d5704b'),
(7, 'Vlados', 'vladosik', 'vladosik@d.d', '26c94912da8f5cedc798a36663e5d3c4', 'nastya.jpg', 0, 1494280364, ''),
(8, 'popandos', 'popandos', 'popandos@sdf.sdf', 'da51b776d084fd951bf34001ec6e3a2a', NULL, 0, 1494280645, '5910e9c593fb3'),
(9, 'vlaadsdf', 'sdfasdfasdf', 'asdfSDF@sdf.sdf', 'b49604dced50830c0232e919d21aa4e8', NULL, 0, 1494502950, '59144e266ee58'),
(10, 'asdasdasdasd', 'asdasdasdasd23', 'aafdsd@sdf.sdf', '743b4bfb010db0998d4f0bbe147df0da', NULL, 0, 1494503172, '59144f048e49a'),
(11, 'sdflsjdflkjsdf', 'lsdksldkmsdlfkm', 'lsdksldkmsdlfkm@sg.sdf', 'fa97e3425a524e51111fcdb041197e51', NULL, 0, 1494503445, '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `dipinit_articles`
--
ALTER TABLE `dipinit_articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_categories`
--
ALTER TABLE `dipinit_categories`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_comments`
--
ALTER TABLE `dipinit_comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_forums`
--
ALTER TABLE `dipinit_forums`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_genres`
--
ALTER TABLE `dipinit_genres`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_menu`
--
ALTER TABLE `dipinit_menu`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_order`
--
ALTER TABLE `dipinit_order`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_platforms`
--
ALTER TABLE `dipinit_platforms`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_products`
--
ALTER TABLE `dipinit_products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_slider`
--
ALTER TABLE `dipinit_slider`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_subforums`
--
ALTER TABLE `dipinit_subforums`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `dipinit_users`
--
ALTER TABLE `dipinit_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `dipinit_articles`
--
ALTER TABLE `dipinit_articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `dipinit_categories`
--
ALTER TABLE `dipinit_categories`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `dipinit_comments`
--
ALTER TABLE `dipinit_comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `dipinit_forums`
--
ALTER TABLE `dipinit_forums`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `dipinit_genres`
--
ALTER TABLE `dipinit_genres`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT для таблицы `dipinit_menu`
--
ALTER TABLE `dipinit_menu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `dipinit_order`
--
ALTER TABLE `dipinit_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `dipinit_platforms`
--
ALTER TABLE `dipinit_platforms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `dipinit_products`
--
ALTER TABLE `dipinit_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `dipinit_slider`
--
ALTER TABLE `dipinit_slider`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT для таблицы `dipinit_subforums`
--
ALTER TABLE `dipinit_subforums`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `dipinit_users`
--
ALTER TABLE `dipinit_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
