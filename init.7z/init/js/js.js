
  // var boxes = document.getElementsByClassName('post_wrap');
  // var tmp = 0;
  // for (var i = 0; i < boxes.length; i++) {
  //   if (boxes[i].offsetHeight > tmp) {
  //     tmp = boxes[i].offsetHeight;
  //   }
  // }
  // for (var z = 0; z < boxes.length; z++) {
  //   boxes[z].style.height = tmp + "px";
  // }
var fh = $("footer").css("height");
$(".wrapper").css("margin-bottom", "-" + fh);
$(".page-buffer").css("height", fh);

$("#about").click(function(){
  var display = $("#prof_info").css("display");
  if(display == "none")
    $("#prof_info").css("display", "block");
  else
    $("#prof_info").css("display", "none");
});
  $('.slider').slick({
    autoplay: true,
    autoplaySpeed: 10000,
    dots: true,
    arrows: false
  });

  var tmp_id = 0;
var tmp_comment = null;

$(document).ready(function() {
  
  $(".captcha img:first-child").bind("click", function(event) {
    var captcha = $(".captcha img:last-child");
    var src = $(captcha).attr("src");
    if ((i = src.indexOf("?")) == -1) src += "?" + Math.random();
    else src = src.substring(0, i) + "?" + Math.random();
    $(captcha).attr("src", src);
  });
  
  $(document).on("click", "#comment_cancel span", function(event) {
    commentCancel();
  });
  
  // $(document).on("click", ".reply_comment", function(event) {
  //   //commentCancel();
  //   var
  //   showFormComment();
  // });
  
  $(document).on("click", "#comments .reply_comment", function(event) {
    commentCancel();
    var parent_id = $(event.target).parents("div").get(0).id;
    $("#form_add_comment").appendTo("#" + parent_id);
    $("#form_add_comment #parent_id").val(parent_id.substr("comment_".length));
    showFormComment();
  });

  // $(document).on("click", "#add_cart", function(event) {
  //  // alert("The product was successfully added to the cart!")
  //   var query;
  //  var parent_id = $(event.target).parents("div").get(0).id;
  //   query = "func=add_cart&product_id=" + product_id;
  //   alert(query);
  //   ajax(query, error, successAddCart);

  //  });
  
  $(document).on("click", "#form_add_comment .button", function(event) {
    if ($("#form_add_comment textarea").val()) {
      var query;
      var comment_id = $("#comment_id").val();
      var text_comment = $("#text_comment").val();
      if (comment_id != 0) {
        query = "func=edit&obj=comment&name=text_" + comment_id + "&value=" + encodeURIComponent(text_comment);
        ajax(query, error, successEditComment);
      }
      else {
        var parent_id = $("#parent_id").val();
        var forum_id = $("#lol").val();
        query = "func=add_comment&parent_id=" + parent_id + "&lol=" + forum_id + "&text=" + encodeURIComponent(text_comment);
        //alert(query);
        ajax(query, error, successAddComment);
      }
    }
    else alert("You do not enter comment!");
  });

  $(document).on("click", "#main_add_comment .mbutton", function(event) {
    if ($("#main_add_comment textarea").val()) {
      var query;
      var comment_id = $("#mcomment_id").val();
      var text_comment = $("#mtext").val();
        var parent_id = 0;
        var forum_id = $("#lol").val();
        query = "func=add_comment&parent_id=" + parent_id + "&lol=" + forum_id + "&text=" + encodeURIComponent(text_comment);
        ajax(query, error, successAddComment);
      
    }
    else alert("You do not enter comment!");
  });
  
  $(document).on("click", "#comments .edit_comment", function(event) {
    commentCancel();
    var parent_id = $(event.target).parents("div").get(0).id;
    tmp_comment = $("#" + parent_id).clone();
    $("#form_add_comment #comment_id").val(parent_id.substr("comment_".length));
    var temp = $("#" + parent_id + " .text").html();
    temp = temp.replace(/&lt;/g, "<");
    temp = temp.replace(/&gt;/g, ">");
    temp = temp.replace(/&amp;/g, "&");
    $("#form_add_comment #text_comment").val(temp);
    $($("#" + parent_id)).replaceWith($("#form_add_comment"));
    showFormComment();
  });
  
  $(document).on("click", "#comments .delete_comment", function(event) {
    commentCancel();
    if (confirm("Are you sure you want to delete the comment?")) {
      var comment_id = $(event.target).parents("div").get(0).id.substring("comment_".length);
      tmp_id = comment_id;
      var query = "func=delete&obj=comment&id=" + comment_id;
      ajax(query, error, successDeleteComment);
    }
  });

  //  $(document).on("click", ".delete_prod", function(event) {
  //   commentCancel();
  //   if (confirm("Are you sure you want to delete product?")) {
  //     var comment_id = $(event.target).parents("div").get(0).id.substring("comment_".length);
  //     tmp_id = comment_id;
  //     var query = "func=delete&obj=comment&id=" + comment_id;
  //     ajax(query, error, successDeleteComment);
  //   }
  // });

  

});

function error() {
  alert("Error! Try later.");
}

function succsessAddCart(data){
  data = data["r"];
}

function successAddComment(data) {
  data = data["r"];
  data = JSON.parse(data);
  var comment = getTemplateComment(data.id, data.user_id, data.login, data.avatar, data.text, data.date);
  if (data.parent_id != 0) {
    $("#form_add_comment").appendTo("#comments");
    $("#comment_" + data.parent_id).append(comment);
  }
  else $("#form_add_comment").before(comment);
  
  closeFormComment();
}

function successEditComment(data) {
  if (data["r"]) $(tmp_comment).find(".text").html(data["r"]);
  if (data) {
    var form = $("#form_add_comment").clone();
    $("#form_add_comment").replaceWith($(tmp_comment));
    tmp_comment = null;
    $(form).appendTo("#comments");
  }
  else error();
  closeFormComment();
}

function successDeleteComment(data) {
  if (data["r"]) {
    $("#comment_" + tmp_id).fadeOut(500, function() {
      $("#comment_" + tmp_id).remove();
      $("#count_comments").text($(".comment").length);
      tmp_id = 0;
    });
  }
  else error();
}

function getTemplateComment(id, user_id, login, avatar, text, day_text) {
  var str = "<div class='comment' id='comment_" + id + "'>";
  str += "<div class='forum_avatar'>";
  str += "<img src='" + avatar + "' alt='" + login + "' class='profileImg'/>";
  str += "</div>";
  str += "<div class='author'>";
  str += "<span class='login'>" + login + "</span><span class='date'>" + day_text +"</span>";
  str += "</div>";
  str += "<div class='question_text'><p>" + text + "</p></div>";
  str += "<div class='functions'><div class='comment_edit'><span class='reply_comment'>Reply</span><span class='edit_comment'>Edit</span><span class='delete_comment'>Delete</span></div></div>"; 
  str += "</div>";
  return str;
}

function showFormComment() {
  $("#form_add_comment").css("display", "block");
  $("#form_add_comment textarea").focus();
}

function commentCancel() {
  if (tmp_comment) {
    successEditComment(true);
  }
  closeFormComment();
}

function closeFormComment() {
  $("#form_add_comment #parent_id").val(0);
  $("#form_add_comment #text_comment").val("");
  $("#form_add_comment #comment_id").val(0);
  $("#form_add_comment").css("display", "none");
  $("#count_comments").text($(".comment").length);
}


function ajax(data, func_error, func_success) {
  $.ajax({
    url: "/api.php",
    type: "POST",
    data: (data),
    dataType: "text",
    error: func_error,
    success: function(result) {
      //alert(result);
      result = $.parseJSON(result);
      func_success(result);
    }
  });
}