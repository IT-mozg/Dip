<?php

abstract class ObjectDB extends AbstractObjectDB {
	
	private static $months = array("January", "February", "March", "April", "May", "June",
	 "July", "August", "September", "October", "November", "December");

	private static $daytext = array("just", "minutes ago", "hours ago", "yesterday", "days ago");
	
	public function __construct($table) {
		parent::__construct($table, Config::FORMAT_DATE);
	}
	
	protected static function getMonth($date = false) {
		if ($date) $date = strtotime($date);
		else $date = time();
		return self::$months[date("n", $date) - 1];
	}

	protected function getYear($date = false){
		if ($date) $date = strtotime($date);
		else $date = time();
		return date("Y", $date);
	}

	final protected function getDateText($date){
		$dh = $date;
		$now = time();
		$nowday = date("j", $now);
		$nowmonth = date("n", $now);
		$nowyear = date("Y", $now);
		$nowminute = date("i", $now);
		$nowhour = date("G", $now);

		$date = strtotime($date);
		$div = $now - $date;

		$m = floor($div / 60);
		$h = floor($div /(60*60));
		$d = floor($div /(60*60*24));

		if($m <= 2)
			return self::$daytext[0];
		else if ($m < 60)
			return $m." ".self::$daytext[1];
		else if ($h < 24)
			return $h." ".self::$daytext[2];
		else if ($d == 1)
			return self::$daytext[3];
		else if ($d <= 7)
			return $d." ".self::$daytext[4];
		return $this->getDay($dh)." ".$this->getMonth($dh)." ".$this->getYear($dh);
	}

	public static function isEmpty($field){
		trim($field);
		if(is_null($field) || $field == "") return false;
		return true;
	}

	public static function setMeta_key($title){
		$arr = explode(" ", $title);
		$meta_keys = "";
		foreach ($arr as $value) {
			$meta_keys .= $value.", ";
		}
		return substr($meta_keys, 0, -2);
	}
	
	public function preEdit($field, $value) {
		return true;
	}
	
	public function postEdit($field, $value) {
		return true;
	}
	
	public function accessEdit($auth_user, $field) {
		return false;
	}
	
	public function accessDelete($auth_user) {
		return false;
	}
	
}

?>