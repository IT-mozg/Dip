<?php 

class AddTopik extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("auth_user");
		$this->add("form");
	}

	public function getTmplFile(){
		return "addtopik";
	}
}

 ?>