<?php

class Article extends Module {
	
	public function __construct() {
		parent::__construct();
		$this->add("article");
		$this->add("sidebar");
		$this->add("prev_article");
		$this->add("next_article");
	}
	
	public function getTmplFile() {
		return "article";
	}
	
}

?>