<?php 

class Cart extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("products", null, true);
		$this->add("action");
		$this->add("name");
	}

	public function preRender(){
		$this->add("total_price");
		$total_price = 0;
		foreach($this->products as $prod) $total_price += (int) $prod->product->price;
		$this->total_price = $total_price;
	}

	public function getTmplFile(){
		return "cart";
	}
}

 ?>