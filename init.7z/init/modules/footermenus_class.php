<?php 

class FooterMenus extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("menu", null, true);
	}

	public function addMenu($header, $items){
		$cl = new stdClass();
		$cl->header = $header;
		$cl->items = $items;
		$this->menu = $cl;
	}

	public function getTmplFile(){
		return "footermenus";
	}
}

 ?>