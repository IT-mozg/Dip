<?php 

class Form extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("name");
		$this->add("action");
		$this->add("method", "post");
		$this->add("header");
		$this->add("message");
		$this->add("check", true);
		$this->add("enctype");
		$this->add("textarea");
		$this->add("inputs", null, true);
		$this->add("jsv", null, true);
	}

	public function addJSV($field, $jsv){
		$this->addObj("jsv", $field, $jsv);
	}

	public function text($name, $label = "", $value = "", $default_v = "", $class = false){
		$this->input($name, "text", $label, $value, $default_v, $class);
	}

	public function textarea($name, $label = "", $value = "", $default_v = "", $class = false){
		$this->input($name, "textarea", $label, $value, $default_v, $class);
	}

	public function select($name, $label = "", $class, $options){
		$this->input($name, "select", $label, false, false, $class, $options);
	}

	public function password($name, $label = "", $default_v = "", $class = false){
		$this->input($name, "password", $label, "", $default_v, $class);
	}

	public function captcha($name, $label, $class = false) {
		$this->input($name, "captcha", $label, "", "", $class);
	}

	public function file($name, $label, $value, $class = false) {
		$this->input($name, "file", $label, $value, "", $class);
	}

	public function hidden($name, $value) {
		$this->input($name, "hidden", "", $value);
	}

	public function submit($value, $name = false, $class = false) {
		$this->input($name, "submit", "", $value, "", $class);
	}

	private function input($name, $type, $label, $value = false, $default_v = false, $class = false, $options = false) {
		$cl = new stdClass();
		$cl->name = $name;
		$cl->type = $type;
		$cl->label = $label;
		$cl->value = $value;
		$cl->default_v = $default_v;
		$cl->class = $class;
		$cl->options = $options;
		$this->inputs = $cl;
	}

	public function getTmplFile() {
		return "form";
	}
}

 ?>