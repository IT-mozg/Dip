<?php 

class Forums extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("forums", null, true);
		$this->add("pagination");
	}

	public function getTmplFile(){
		return "forums";
	}
}

 ?>