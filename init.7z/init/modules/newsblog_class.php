<?php 

class NewsBlog extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("news", null, true);
		$this->add("pagination");
	}

	public function getTmplFile(){
		return "newsblog";
	}
}

 ?>