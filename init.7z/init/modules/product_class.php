<?php 

class Product extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("product");
	}

	public function getTmplFile(){
		return "product";
	}
}

 ?>