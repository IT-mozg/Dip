<?php 

class ProfileNav extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("uri");
		$this->add("items", null, true);
	}

	public function addItem($title, $link, $type){
		$std = new stdClass();
		$std->link = $link;
		$std->title = $title;
		$std->type = $type;
		$this->items = $std;
	}

	public function getTmplFile(){
		return "profilenav";
	}
}

 ?>