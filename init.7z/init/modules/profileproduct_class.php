<?php 

class ProfileProduct extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("products", null, true);
	}

	public function getTmplFile(){
		return "profileproduct";
	}
}

 ?>