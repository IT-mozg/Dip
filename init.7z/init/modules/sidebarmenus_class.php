<?php 

class SidebarMenus extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("menu", null, true);
	}

	public function addMenu($header, $items, $type){
		$cl = new stdClass();
		$cl->header = $header;
		$cl->items = $items;
		$cl->type = $type;
		$this->menu = $cl;
	}

	public function getTmplFile(){
		return "sidebarmenus";
	}
}

 ?>