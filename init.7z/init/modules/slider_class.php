<?php 

class Slider extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("items", null, true);
	}

	public function getTmplFile(){
		return "slider";
	}
}

 ?>