<?php 

class Store extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("products", null, true);
		$this->add("pagination");
	}

	public function getTmplFile(){
		return "store";
	}
}

 ?>