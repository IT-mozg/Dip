<?php 

class SubForums extends Module{

	public function __construct(){
		parent::__construct();
		$this->add("subforums", null, true);
		$this->add("header");
		$this->add("pagination");
	}

	public function getTmplFile(){
		return "subforums";
	}
}

 ?>