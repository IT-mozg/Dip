<?php 

class ForumDB extends ObjectDB{

	protected static $table = "forums";

	public function __construct(){
		parent::__construct(self::$table);
		$this->add("title", "ValidateTitle");
		$this->add("date", "ValidateDate", self::TYPE_TIMESTAMP, $this->getDate());
		$this->add("meta_desc", "ValidateMD");
		$this->add("meta_key", "ValidateMK");
	}

	protected function postInit(){
		$this->link = URL::getArg("forum", "", array($this->id));
		$this->count_subforums = SubForumDB::getCountByForumID($this->id);
		$this->day_text = ObjectDB::getDateText($this->date);
		return true;
	}

	public static function getAllOffset($count, $offset = false, $order = false){
		$select = new Select();
		$select->from(self::$table, "*")->order("date", $order);
		if($count)
			$select->limit($count, $offset);
		$data = self::$db->select($select);
		$forums = ObjectDB::buildMultiple(__CLASS__, $data);
		return $forums;
	}
}

 ?>