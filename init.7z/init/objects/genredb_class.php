<?php 

class GenreDB extends ObjectDB{

	protected static $table = "genres";

	public function __construct() {
		parent:: __construct(self::$table);
		$this->add("title", "validateTitle");
	}

	public static function getByIDS($ids){
		$select = new Select(self::$db);
		$select->from(self::$table, "*");
		$ids = explode(",", $ids);
		for($i = 0; $i < count($ids); $i++){
			$ids[$i] = (int) $ids[$i];
		}
		$select->whereIN("id", $ids);
		$data = self::$db->select($select);
		$objects = ObjectDB::buildMultiple(__CLASS__, $data);
		return $objects;
	}
}

 ?>