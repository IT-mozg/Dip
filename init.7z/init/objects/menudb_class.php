<?php 

class MenuDB extends ObjectDB{

	protected static $table = "menu";

	public function __construct(){
		parent::__construct(self::$table);
		$this->add("type", "ValidateID");
		$this->add("title", "ValidateTitle");
		$this->add("link", "ValidateURL");
		$this->add("parent_id", "ValidateID");
		$this->add("external", "ValidateBoolean");
	}

	public static function getTopMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", TOPMENU, "id");
	}
	
	public static function getFootMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", FOOTMENU, "id");
	}

	public static function getGamesMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", GAMESMENU, "id");
	}

	public static function getProgramsMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", PROGRAMSMENU, "id");
	}

	public static function getCategoriesMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", CATEGORIESMENU, "id");
	}

	public static function getProfileMenu() {
		return ObjectDB::getAllOnField(self::$table, __CLASS__, "type", PROFILEMENU, "id");
	}
}

 ?>