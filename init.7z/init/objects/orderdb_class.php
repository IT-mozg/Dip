<?php 

class OrderDB extends ObjectDB{

	protected static $table = "order";

	public function __construct(){
		parent::__construct(self::$table);
		$this->add("product_id", "ValidateID");
		$this->add("user_id", "ValidateID");
		$this->add("date", "ValidateDate", self::TYPE_TIMESTAMP, $this->getDate());
	}

	protected function postInit(){
		$this->delete_cart_link = URL::get("cart", "user", array("delete_cart" => $this->id));
	}

	public static function getByUserID($user_id){
		$select = new Select();
		$select->from(self::$table, "*");
		$select->where("`user_id` = ".self::$db->getSQ(), array($user_id));
		$data = self::$db->select($select);
		$orders = ObjectDB::buildMultiple(__CLASS__, $data);
		foreach($orders as $order){
			$order->postHandling();
		}
		return $orders;
	}

	public static function chekOrder($product_id, $user_id){
		$select = new Select();
		$select->from(self::$table, "*");
		$select->where("`user_id` = ".self::$db->getSQ(), array($user_id))->where("`product_id` = ".self::$db->getSQ(), array($product_id));
		$data = self::$db->selectRow($select);
		if($data) return true;
		return false;
	}

	private function postHandling(){
		$prod_db = new ProductDB();
		$prod_db->load($this->product_id);
		if($prod_db->isSaved()) $this->product = $prod_db;
	}

	public function accessDelete($auth_user) {
		echo $this->user_id;
		return $this->user_id == $auth_user->id;
	}
}

 ?>