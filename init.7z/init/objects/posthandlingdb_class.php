<?php 

class PostHandlingDB extends ObjectDB{

	private static $table;

	public function __construct($table){
		parent::__construct($table);
		self::$table = $table;
	}

	protected static function getBaseSelect(){
		$select = new Select(self::$db);
		$select->from(self::$table, "*");
		return $select;
	}


	public static function getAllbyType($type, $order = false, $offset){
		$select = self::getBaseSelect();
		$select->where("`type` = ".self::$db->geSQ(), array($type))
			->order("date", $order);
		$data = self::$db->select($select);
		$articles = ObjectDB::buildMultiple(get_called_class(), $data);
		return $articles;
	}

	public static function getAllShow($count = false, $offset = false, $post_handling = false){
		$select = self::getBaseSelect();
		$select->order("date", false);
		if($count) $select->limit($count, $offset);
		$data = self::$db->select($select);
		$objects = ObjectDB::buildMultiple(get_called_class(), $data);
		if($post_handling) foreach ($objects as $obj) $obj->postHandling();
		return $objects;
	}

	protected function getByIDS($class, $ids){
		$select = $this->getBaseSelect();
		$ids = explode(",", $ids);
		for($i = 0; $i < count($ids); $i++){
			$ids[$i] = (int) $ids[$i];
		}
		$select->whereIN("id", $ids);
		$data = self::$db->select($select);
		$objects = ObjectDB::buildMultiple($class, $data);
		return $objects;
	}

	protected function postHandling(){}
}

 ?>