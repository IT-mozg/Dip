<?php 

class ProductDB extends ObjectDB{

	protected static $table = "products";

	public function __construct(){
		parent::__construct(self::$table);
		$this->add("title", "ValidateTitle");
		$this->add("intro", "ValidateText");
		$this->add("text", "ValidateText");
		$this->add("intro_img", "ValidateIMG");
		$this->add("text_img", "ValidateIMG");
		$this->add("src", "ValidateFile");
		$this->add("type", "ValidateProductType");
		$this->add("genre_ids", "ValidateIDs");
		$this->add("platform_ids", "ValidateIDs");
		$this->add("price", "ValidatePositiveNumber");
		$this->add("meta_desc", "ValidateMD");
		$this->add("meta_key", "ValidateMK");
		$this->add("date", "ValidateDate", self::TYPE_TIMESTAMP, $this->getDate());
	}

	protected function postInit() {
		if(!is_null($this->intro_img)) $this->intro_img = Config::DIR_IMG_PRODUCTS.$this->intro_img;
		if(!is_null($this->text_img)) $this->text_img = Config::DIR_IMG_PRODUCTS.$this->text_img;
		$this->link = URL::get("product", "", array("id" => $this->id));
		$this->add_cart_link = URL::get("product", "", array("add_cart" => $this->id));
		return true;
	}

	protected function postLoad() {
		$this->postHandling();
		return true;
	}

	public static function getByFilter($type, $genre_ids, $platform_ids){
		$select = $this->getBaseSelect();
		$select->where("`type` = ".self::$db->getSQ(), array($type));
		if($genre_ids)
			foreach ($genre_ids as $id) {
				$select->whereFIS("genre_ids", $id);
			}
		if($platform_ids)
			foreach ($platform_ids as $id) {
				$select->whereFIS("platform_ids", $id);
			}
		$data = self::$db->select($select);
		$produncts = ObjectDB::buildMultiple(__CLASS__, $data);
		return $produncts;
		
	}

	public static function getAllbyType($type, $order = false, $offset){
		$select = self::getBaseSelect();
		$select->where("`type` = ".self::$db->geSQ(), array($type))
			->order("date", $order);
		$data = self::$db->select($select);
		$articles = ObjectDB::buildMultiple(get_called_class(), $data);
		return $articles;
	}

	public static function getAllShow($count = false, $offset = false, $post_handling = false){
		$select = self::getBaseSelect();
		$select->order("date", false);
		if($count) $select->limit($count, $offset);
		$data = self::$db->select($select);
		$objects = ObjectDB::buildMultiple(get_called_class(), $data);
		if($post_handling) foreach ($objects as $obj) $obj->postHandling();
		return $objects;
	}

	private function setGenresAndPlatforms(){
		$this->genres = GenreDB::getByIDS($this->genre_ids);
		$this->platforms = PlatformDB::getByIDS($this->platform_ids);
	}

	private static function getBaseSelect(){
		$select = new Select(self::$db);
		$select->from(self::$table, "*");
		return $select;
	}

	private function postHandling(){
		$this->setGenresAndPlatforms();
		$this->day_show = ObjectDB::getDay($this->date);
		$this->month_show = ObjectDB::getMonth($this->date);
	}
}

 ?>