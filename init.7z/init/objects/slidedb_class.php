<?php 

class SlideDB extends ObjectDB{

	protected static $table = "slider";

	public function __construct() {
		parent:: __construct(self::$table);
		$this->add("title", "ValidateTitle");
		$this->add("description", "ValidateText");
		$this->add("img", "ValidateIMG");
	}

	public static function getAllSlides(){
		$select = new Select();
		$select->from(self::$table, "*");
		$data = self::$db->select($select);
		$slides = ObjectDB::buildMultiple(__CLASS__, $data);
		return $slides;
	}

	protected function postInit(){
		$this->img = Config::DIR_IMG_SLIDER.$this->img;
		return true;
	}

	protected function preValidate(){
		$this->img = basename($this->img);
		return true;
	}
}

 ?>