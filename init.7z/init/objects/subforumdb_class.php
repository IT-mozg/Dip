<?php 

class SubForumDB extends ObjectDB{

	protected static $table = "subforums";

	public function __construct(){
		parent::__construct(self::$table);
		$this->add("title", "ValidateTitle");
		$this->add("text", "ValidateText");
		$this->add("user", "ValidateID");
		$this->add("forum_id", "ValidateID");
		$this->add("meta_desc", "ValidateMD");
		$this->add("meta_key", "ValidateMK");
		$this->add("date", "ValidateDate", self::TYPE_TIMESTAMP, $this->getDate());
	}

	protected function postInit(){
		$this->link = URL::get("subforum", "", array("id" => $this->id));
		$this->count_comments = CommentDB::getCountOnForumID($this->id);
		$this->day_text = ObjectDB::getDateText($this->date);
		return true;
	}

	protected function postLoad(){
		$this->postHandling();
		return true;
	}

	public static function getAllByForumID($forum_id, $count = false, $offset = false, $order = false){
		$select = new Select();
		$select->from(self::$table, "*");
		$select->where("`forum_id` = ".self::$db->getSQ(), array($forum_id));
		if($count) $select->limit($count, $offset);
		$select->order("date", $order);
		$data = self::$db->select($select);
		$objects = ObjectDB::buildMultiple(__CLASS__, $data);
		foreach ($objects as $obj) $obj->postHandling();
		return $objects;
	}

	// public function getAllByForumID($forum_id){
	// 	return ObjectDB::getAllOnField(self::$table, __CLASS__, "forum_id", $forum_id);
	// }

	public static function getCountByForumID($forum_id){
		return ObjectDB::getCountOnField(self::$table, "forum_id", $forum_id);
	}

	private function postHandling(){
		$user = new UserDB();
		$user->load($this->user);
		if($user->isSaved()) $this->user = $user;

		$forum = new ForumDB();
		$forum->load($this->forum_id);
		if($forum->isSaved()) $this->forum = $forum;
	}
}

 ?>