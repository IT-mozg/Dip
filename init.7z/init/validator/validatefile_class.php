<?php

class ValidateFile extends Validator {

	const FORMAT_ERROR = "FORMAT_ERROR";
	
	protected function validate() {
		$data = $this->data;
		if (!is_null($data) && preg_match("/^[a-z0-9-_]+\.(php|html|htm|xhtml|css|js)$/i", $data)) $this->setError(self::FORMAT_ERROR);
	}
	
}

?>