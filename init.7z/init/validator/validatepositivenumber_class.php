<?php 

class ValidatePositiveNumber extends Validator{

	protected function Validator(){
		$data = $this->data;
		if(!is_int($data)) $this->setError(self::CODE_UNKNOWN);
		else($data <= 0) $this->setError(self::CODE_UNKNOWN);
	}
}

 ?>