<?php

class ValidateProductType extends Validator {

	const MAX_PRODUCTTYPE = 2;
	
	protected function validate() {
		$data = $this->data;
		if (!is_int($data)) $this->setError(self::CODE_UNKNOWN);
		else {
			if (($data < 1) || ($data > self::MAX_PRODUCTTYPE)) $this->setError(self::CODE_UNKNOWN);
		}
	}
	
}

?>