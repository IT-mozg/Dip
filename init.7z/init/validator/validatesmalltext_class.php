<?php

class ValidateSmallText extends ValidateText {
	
	const MAX_LEN = 500;
	
}

?>