<?php 

class ValidateUserType extends Validator {

	const MAX_USERTYPE = 10;

	protected function validate(){
		$data = (int)$this->data;
		if (!is_int($data)) $this->setError(self::CODE_UNKNOWN);
		else {
			if (($data < 0) || ($data > self::MAX_USERTYPE)){
				$this->setError(self::CODE_UNKNOWN);
			}
		}
	} 
}

 ?>